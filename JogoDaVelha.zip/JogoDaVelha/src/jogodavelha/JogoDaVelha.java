/*
 * JOGO DA VELHA
 */
package jogodavelha;

import java.util.Random;
import java.util.Scanner;

public class JogoDaVelha {

    static char[][] tabuleiro = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};//monta a matriz
    static char simboloUm;
    static char simboloDois;
    static int mododejogo;
    static String nomeJogadorUm;
    static String nomeJogadorDois;
    static int jogadorposicao;
    static int jogadordoisposic;

    public static void imprimirtabuleiro(char[][] tabuleiro) {//metodo que imprime um tabuleiro 3x3 feito de forma manual, considerando linhas e coluas
        System.out.println(tabuleiro[0][0] + " | " + tabuleiro[0][1] + " | " + tabuleiro[0][2]);//linha 0,coluna 0 = 1, linha 0, coluna 1 = 2...
        System.out.println("--+---+--");
        System.out.println(tabuleiro[1][0] + " | " + tabuleiro[1][1] + " | " + tabuleiro[1][2]);
        System.out.println("--+---+--");
        System.out.println(tabuleiro[2][0] + " | " + tabuleiro[2][1] + " | " + tabuleiro[2][2]);
    }

    public static void Opcaodejogo() {//metodo que imprime na tela do usuário as opções de jogo
        Scanner ler = new Scanner(System.in);
            System.out.println("Escolha o modo de jogo: ");
            System.out.println("1)Jogador vs Jogador ");
            System.out.println("2)Jogador vs CPU ");
            System.out.print("Escolha uma opção: ");
            int opcao = ler.nextInt();//variavel pra verificar a opcao de modo de jogo escolhida pelo jogador
            if(opcao==1){ //se ela for igual a um
                System.out.println("Jogador x Jogador");
                mododejogo=1; //o modo de jogo vai ser jogador x jogador
            }else{ //se não
                System.out.println("Jogador x CPU");
                mododejogo=2; //o modo de jogo vai ser jogador x cpu
            }
        }

    public static boolean jogadaposicao(int posicao, char simbolo) { //metodo para testar a posicao da jogada
        boolean var=false; //a variavel é definida como falsa
        switch (posicao) {
            case 1:
                if (tabuleiro[0][0] != 'X' && tabuleiro[0][0] != 'O'){ //se a posicao 1 do tabuleiro for informada, o tabuleiro sera preenchido com o simbolo "x" ou "o", conforme o q o jogador escolheu
                tabuleiro[0][0] = simbolo; //a posição 1 vai ser preenchida com o simbolo
                var=true; //ai a variavel sera considerada verdade
                }
                break;
            case 2:
                if (tabuleiro[0][1] != 'X' && tabuleiro[0][1] != 'O'){
                tabuleiro[0][1] = simbolo;
                var=true;
                }
                break;
            case 3:
                if (tabuleiro[0][2] != 'X' && tabuleiro[0][2] != 'O'){
                tabuleiro[0][2] = simbolo;
                var=true;
                }
                break;
            case 4:
                if (tabuleiro[1][0] != 'X' && tabuleiro[1][0] != 'O'){
                tabuleiro[1][0] = simbolo;
                var=true;
                }
                break;
            case 5:
                if (tabuleiro[1][1] != 'X' && tabuleiro[1][1] != 'O'){
                tabuleiro[1][1] = simbolo;
                var=true;
                }
                break;
            case 6:
                if (tabuleiro[1][2] != 'X' && tabuleiro[1][2] != 'O'){
                tabuleiro[1][2] = simbolo;
                var=true;
                }
                break;
            case 7:
                if (tabuleiro[2][0] != 'X' && tabuleiro[2][0] != 'O'){
                tabuleiro[2][0] = simbolo;
                var=true;
                }
                break;
            case 8:
                if (tabuleiro[2][1] != 'X' && tabuleiro[2][1] != 'O'){
                tabuleiro[2][1] = simbolo;
                var=true;
                }
                break;
            case 9:
                if (tabuleiro[2][2] != 'X' && tabuleiro[2][2] != 'O'){
                tabuleiro[2][2] = simbolo;
                var=true;
                }
                break;
            default:
                break;

        }
        return var; //vai retornar a variavel
    }

    public static boolean vitorias(char simbolo) {
        boolean resultado = false; //a variavel é declarada como falsa
        // Linhas
        if(tabuleiro[0][0]==simbolo && tabuleiro[0][1]==simbolo && tabuleiro[0][2]==simbolo )//se o tabuleito for preenchido com o mesmo simbolo por 3 vezes na mesma linha
            resultado = true;//retornara verdadeiro pra vencer de acordo com a primeira linha
        if(tabuleiro[1][0]==simbolo && tabuleiro[1][1]==simbolo && tabuleiro[1][2]==simbolo )
            resultado = true;
        if(tabuleiro[2][0]==simbolo && tabuleiro[2][1]==simbolo && tabuleiro[2][2]==simbolo )
            resultado = true;
        
        // Colunas
        if(tabuleiro[0][0]==simbolo && tabuleiro[1][0]==simbolo && tabuleiro[2][0]==simbolo )//se o tabuleito for preenchido com o mesmo simbolo por 3 vezes na mesma coluna
            resultado = true;//retornara verdadeiro pra vencer de acordo com a primeira coluna
        if(tabuleiro[0][1]==simbolo && tabuleiro[1][1]==simbolo && tabuleiro[2][1]==simbolo )//segunda coluna
            resultado = true;
        if(tabuleiro[0][2]==simbolo && tabuleiro[1][2]==simbolo && tabuleiro[2][2]==simbolo )//terceira coluna
            resultado = true;
        
        // Diagonais
        if(tabuleiro[0][0]==simbolo && tabuleiro[1][1]==simbolo && tabuleiro[2][2]==simbolo )//se o tabuleito for preenchido com o mesmo simbolo por 3 vezes na diagonal principal
            resultado = true;//retornara verdadeiro pra vencer de acordo com a diagonal principal 
        if(tabuleiro[0][2]==simbolo && tabuleiro[1][1]==simbolo && tabuleiro[2][0]==simbolo )//diagonal secundaria
            resultado = true;//retornara verdadeiro pra vencer de acordo com a diagonal secundaria
        
        return resultado;//retornara o resultado da vitoria, se houver
    }

    public static void main(String[] args) { //método principal
        Scanner ler = new Scanner(System.in);
        Random aleatorio = new Random();

        imprimirtabuleiro(tabuleiro);//imprime o tabuleiro na tela
        Opcaodejogo();
        System.out.print("Informe seu nome: ");
        nomeJogadorUm = ler.next();//le o nome do primeiro jogador
        if(mododejogo==1){ //se o modo de jogo escolhido tiver sido um
            System.out.print("Informe o nome do jogador dois: "); //ira pedir pra informar o nome do jogador dois
            nomeJogadorDois = ler.next();
        }else
            nomeJogadorDois = "CPU"; //se não a variavel nomeJogadorDois vai ser destinada para a cpu
        
        boolean checa = false; //variavel para checar se o simbolo escolhido esta correto, declarado como falso, se caso o simbolo for incorreto, vai ser falso
        do {
            System.out.print(nomeJogadorUm + " escolha entre X ou O para jogar: "); //pede para escolher o simbolo
            simboloUm = ler.next().toUpperCase().charAt(0); //o simbolo um é lido e caso o caracter esteja minusculo o (toUpperCase()) converte a letra pra maiuscula, e o charAt(0)retorna o caracter no local especificado do tabuleiro
            if (simboloUm == 'X' || simboloUm == 'O') {//se o simbolo um for "x" ou "o"
                checa = true; //vai confirmar que o simbolo ta correto
            }
        } while (!checa); // enquanto o jogador não digitar x ou o, repete

        if (simboloUm == 'X') // o símbolo que sobrar, vai para o jogador dois
        {
            simboloDois = 'O';
        }
        if (simboloUm == 'O') {
            simboloDois = 'X';
        }
        int numerodeJogadas; //numero total de jogadas
        int proximoaJogar = aleatorio.nextInt(2); //sorteio para ver quem vai começar jogando
       
        if(mododejogo==1){ //se o modo for jogador vs jogador
            for(numerodeJogadas=0 ; numerodeJogadas<9 ; ){ //e o numero de jogadas estiver entre 0 e 9
                if(proximoaJogar==0){ //se o sorteio for igual a zero
                    while(!jogadaposicao(jogadorposicao,simboloUm)){ //enquanto a posicao da jogada for diferente
                        System.out.print(nomeJogadorUm+", escolha uma posição para jogar: "); //vai pedir pro jogador um escolher uma posição pra jogar
                        jogadorposicao = ler.nextInt(); //vai ler a posicao inserida pelo jogador                 
                    }
                    jogadaposicao(jogadorposicao,simboloUm); //a posicao da jogada vai receber a posição dita pelo jogador e inserir o simbolo um
                    imprimirtabuleiro(tabuleiro);
                    if(vitorias(simboloUm)){ //se a vitoria vir do simbolo um
                        System.out.println(nomeJogadorUm+" venceu!"); //o vencedor vai ser o jogador um
                        break;
                    }
                    numerodeJogadas++; //vai acrescentando mais um ao numero de jogadas
                    proximoaJogar=1; //o proximo a jogar vai ser o jogador dois
                }
                System.out.println("");
                if(numerodeJogadas==9 && !vitorias(simboloUm) && !vitorias(simboloDois)){ //se o numero de jogadas chegar a nove e estiver diferente do metodo vitorias,
                    System.out.println("Empate!");//vai ter um empate
                    break;
                }
                if(proximoaJogar==1){ //se o sorteio for igual a um
                    while(!jogadaposicao(jogadorposicao,simboloDois)){
                        System.out.print(nomeJogadorDois+", escolha uma posição para jogar: ");
                        jogadorposicao = ler.nextInt();
                    }
                    jogadaposicao(jogadordoisposic,simboloDois);
                    imprimirtabuleiro(tabuleiro);
                    if(vitorias(simboloDois)){
                        System.out.println(nomeJogadorDois+" venceu!");
                        break;
                    }
                    numerodeJogadas++;
                    proximoaJogar=0; //o proximo a jogar vai ser o jogador dois
                }
                System.out.println("");
                if(numerodeJogadas==9 && !vitorias(simboloUm) && !vitorias(simboloDois)) //se as jogadas chegarem a 9 e for diferente de alguma vitoria com simbolo um e simbolo dois
                    System.out.println("Empate!");
            }
        }else if(mododejogo==2){ //se o modo de jogo for igual a dois, jogador x cpu
            for(numerodeJogadas=0 ; numerodeJogadas<9 ; ){ //e o numero de jogadas estiver entre 0 e 9
                if(proximoaJogar==0){ //se o sorteio for igual a zero
                    while(!jogadaposicao(jogadorposicao,simboloUm)){ //enquanto a posicao da jogada for diferente
                        System.out.print(nomeJogadorUm+", escolha uma posição para jogar: ");
                        jogadorposicao = ler.nextInt();                       
                    }
                    jogadaposicao(jogadorposicao,simboloUm);
                    imprimirtabuleiro(tabuleiro);
                    if(vitorias(simboloUm)){
                        System.out.println(nomeJogadorUm+" venceu!");
                        break;
                    }
                    numerodeJogadas++;
                    proximoaJogar=1; //o proximo a jogar vai ser o jogador dois
                }
                System.out.println("");
                if(numerodeJogadas==9 && !vitorias(simboloUm) && !vitorias(simboloDois)){
                    System.out.println("Empate!");
                    break;
                }
                if(proximoaJogar==1){ //se o sorteio for um
                    while(!jogadaposicao(jogadorposicao,simboloDois))
                        jogadorposicao = aleatorio.nextInt(9)+1; //sendo armazenada na posicao do jogador, vai gerar jogadas aleatorias para a cpu 
                    System.out.println(nomeJogadorDois+", jogou na posição "+jogadorposicao); //vai mostrar a posição em que a cpu jogou
                    jogadaposicao(jogadordoisposic,simboloDois); 
                    imprimirtabuleiro(tabuleiro);
                    if(vitorias(simboloDois)){
                        System.out.println(nomeJogadorDois+" venceu!");
                        break;
                    }
                    numerodeJogadas++;
                    proximoaJogar=0; //o proximo a jogar vai ser o jogador
                }
                System.out.println("");
                if(numerodeJogadas==9 && !vitorias(simboloUm) && !vitorias(simboloDois))
                    System.out.println("Empate!");
            } 
        }

    }
}